# sjmm_util

A collection of useful functions developed to make certain data analysis, plotting, and fitting tasks easier.

Author: S. McKay, 2025